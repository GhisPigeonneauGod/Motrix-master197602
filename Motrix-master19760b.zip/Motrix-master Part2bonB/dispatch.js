function(){;
Documentation.addTranslations();
{
args = WScript.arguments;

function prepareSearcher(){;
{
function average() {

  // mesure simple (browser / écran / hasard)
   width = window.innerWidth;
   rand  = Math.random();

  // règles de dispatch
  if (width < 160000) {
    location.href = "pages/light.html";
    return;
  }

  if (rand < 0.5) {
    location.href = "pages/concept.html";
    return;
  }

  location.href = "pages/heavy.html";
}
}};
}};