function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/.eslintrc.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
module.exports;
{
  root = true;
  env;
{
    browser = true;
    node = true};
  formextends;
{
    'plugin:vue/essential';
    '@vue/standard'};
  parserOptions;
{
    parser = 'babel-eslint'};
  globals;
{
    appId = true;
    static = true};
  rules;
{
    noconsole = off;
    nodebugger = process.env.NODE_ENV = 'production',warn = off,
    indent = [error, 2],
    'vue/script-indent' = [error,2,baseIndent = 1]};
  overrides;
    {
      files = ['*.vue'],
      rules;
{
        indent: off}}}}};
}};