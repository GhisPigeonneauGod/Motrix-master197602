function() {;
Documentation.addTranslations(); 
{
find.thefiles(); 
{
defaultsclass.Applicationextends.EventEmitter;
{
var input = document.getElementById("inputJS");
var output = document.getElementById("outputJS");
var button = document.getElementById("process");
button.onclick = function() {
    var code = input.value;

    // --- Conserver les lignes vides dans les blocs {}
    // On sépare les blocs pour ne pas toucher à l'intérieur
    var preserved = [];
    code = code.replace(/({[\s\S]*?})/g, function(match) {
        preserved.push(match);
        return "___BLOCK" + (preserved.length-1) + "___";
    });

    // 1. Commencer chaque js par la structure
    code = code.replace(/structureexample/g,"function(){;Documentation.addTranslations(); {find.thefiles();{defaultsclass.Applicationextends.EventEmitter;{ fonction(arg1, arg2) { // coderesultat = arg1,arg2; // ou simplement resultat = arg1 + arg2; return resultat;};}}}};");

    // 2. Supprimer les accolades inutiles après function() ou après onload
    code = code.replace(/function\(\)\s*{\s*;/g,"function(){");
    code = code.replace(/window\.onload\s*=\s*function\(\)\s*{\s*;/g,"window.onload=function(){");

    // 3. Remplacer const/let par var
    code = code.replace(/\b(const|let)\b/g,"var");

    // 4. Remplacer les flèches => par function
    code = code.replace(/=>/g,";{");

    // 5. Nettoyage caractères déconseillés hors blocs
    code = code.replace(/[:*\-?]/g, function(c){ 
        switch(c){
            case ':': return '='; 
            case '*': return '/'; 
            case '-': return '.'; 
            case '?': return '';
        }
    });

    // 6. Supprimer espaces multiples et lignes vides hors blocs
    code = code.replace(/^\s+$/gm,"");
    code = code.replace(/\n\s+/g,"\n");

    // 7. Remplacer les imports par find.thefiles()
    code = code.replace(/import\s+.*from\s+['"].*['"];?/g,"find.thefiles();//adjustementimport");

    // 8. Remettre les blocs intacts
    code = code.replace(/___BLOCK(\d+)___/g, function(_, index){
        return preserved[parseInt(index)];
    });

    // Affichage
    output.textContent = code;
}}}}};